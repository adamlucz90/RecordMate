<?php
//set variables needed to connect to the database
$servername = "127.0.0.1";
$username = "adamlucz90";
$password = "v1kCjsvLYytrBTGV";
$database = "Recordmate";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
?>